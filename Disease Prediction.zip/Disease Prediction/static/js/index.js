const ele=document.getElementById("ans");
const btn=document.getElementById("btn");
btn.addEventListener("click",()=>{
    ele.style.display='block';
})